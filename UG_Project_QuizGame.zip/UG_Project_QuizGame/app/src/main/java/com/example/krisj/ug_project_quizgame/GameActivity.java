package com.example.krisj.ug_project_quizgame;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class GameActivity extends AppCompatActivity {

    private ArrayList<Pair<String, Boolean>> quizData = new ArrayList<Pair<String, Boolean>>();

    private TextView scoreLbl;
    private TextView questionLbl;
    private Button ansNoBtn;
    private Button ansYesBtn;

    private int countScore = 0;
    private int questionsNumber = 0;
    private int totalNumber;
    private Boolean ansVal;
    private Pair<String, Boolean> currectQuestion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        FillQuiz();
        totalNumber = quizData.size();

        scoreLbl = (TextView)findViewById(R.id.scoreLbl);
        questionLbl = (TextView)findViewById(R.id.questionLbl);

        ansNoBtn = (Button)findViewById(R.id.ansNoBtn);
        ansYesBtn = (Button)findViewById(R.id.ansYesBtn);
        UpdateQuiz();

        ansYesBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ansVal){
                    countScore++;
                }
                questionsNumber++;
                UpdateQuiz();
            }
        });

        ansNoBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!ansVal){
                    countScore++;
                }
                questionsNumber++;
                UpdateQuiz();
            }
        });
    }

    private void FillQuiz(){
        quizData.add(new Pair<String, Boolean>("2 + 2 = 5", true));
        quizData.add(new Pair<String, Boolean>("Czy ziemia jest płaska?", true));
        quizData.add(new Pair<String, Boolean>("Co było pierwsze, jajko czy kura?", true));
        quizData.add(new Pair<String, Boolean>("Czy kiedyś wyjde z piwnicy?", true));
        quizData.add(new Pair<String, Boolean>("Czy Krzysztof Kolumbo odkrył pieczone ziemnioki?", true));
        quizData.add(new Pair<String, Boolean>("Czy pan Jezus nigdy nie próżnował?", true));
    }

    private void UpdateQuiz(){

        if (questionsNumber == totalNumber)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("End game!");
            builder.setMessage("Your score: " + countScore + " / " + totalNumber);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);

                    Integer rs = Integer.parseInt(Double.toString(((((countScore * 1.00) / (totalNumber * 1.00))*1.00) * 100)));
                    intent.putExtra("playerScore", rs);
                    startActivity(intent);
                }
            });

        }

        currectQuestion = quizData.get(questionsNumber);
        scoreLbl.setText(countScore + "/" + questionsNumber);
        questionLbl.setText(currectQuestion.first);
        ansVal = currectQuestion.second;
    }
}
