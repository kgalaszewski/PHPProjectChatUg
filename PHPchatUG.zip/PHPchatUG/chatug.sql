-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 16 Gru 2018, 12:34
-- Wersja serwera: 10.1.37-MariaDB
-- Wersja PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `chatug`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `chat`
--

CREATE TABLE `chat` (
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `chat`
--

INSERT INTO `chat` (`message_id`, `user_id`, `message`, `timestamp`) VALUES
(1, 1, 'testowa wiadomosc Karol', 1544379093),
(2, 2, 'testowa wiadomosc Krzysiek', 1544379093),
(3, 1, 'testwoa wiadomsoc2', 1544380966),
(4, 2, 'testwoa wiadomsoc3', 1544381006),
(5, 2, 'testwoa wiadomsoc3', 1544381010),
(6, 2, 'testwoa wiadomsoc3', 1544381336),
(7, 3, 'lkjk', 1544382224),
(8, 0, 'sdfsdfsdf', 1544382234),
(9, 0, 'sdsd', 1544382237),
(10, 0, 'asdasd', 1544382580),
(11, 0, 'asd', 1544382582),
(12, 0, 'a', 1544382583),
(13, 0, 'asd', 1544382622),
(14, 0, 'asd', 1544382623),
(15, 0, 'asd', 1544382624),
(16, 0, 'asd', 1544382877),
(17, 0, 'd', 1544382878),
(18, 0, 'd', 1544382878),
(19, 0, 'd', 1544382878),
(20, 0, 'elo', 1544383009),
(21, 0, 'test', 1544383026),
(22, 0, 'raz', 1544383087),
(23, 0, 'ddd', 1544383207),
(24, 0, 'aaa', 1544383211),
(25, 0, 'http://localhost/phpmyadmin/sql.php?server=1&amp;db=chatug&amp;table=chat&amp;pos=0', 1544383261),
(26, 0, 'a', 1544383365),
(27, 0, 'aaa', 1544383561),
(28, 3, 'asd', 1544383583),
(29, 2, 'asd', 1544383596),
(30, 2, 'asd', 1544383608),
(31, 0, 'asd', 1544384440),
(32, 0, 'aaa', 1544384443),
(33, 0, 'razraz', 1544384467),
(34, 0, '', 1544384607),
(35, 0, '', 1544384616),
(36, 0, 'x', 1544384652),
(37, 0, '', 1544384706),
(38, 0, '', 1544384726),
(42, 0, 'a', 1544384898),
(43, 0, '', 1544384919),
(44, 0, '', 1544385062),
(46, 1, 'z', 1544385348),
(47, 1, 'xc', 1544385353),
(48, 0, 'zxczxc', 1544385357),
(49, 1, 'zzz', 1544385376),
(50, 0, 'aaa', 1544385435),
(51, 0, 'z', 1544385445),
(52, 0, 'a', 1544385451),
(53, 0, 'asdasd', 1544385456),
(54, 0, 'asdasd', 1544385467),
(55, 1, 'z', 1544385470),
(56, 0, 'z', 1544385922),
(57, 0, 'raz', 1544386093),
(58, 0, 'x', 1544386123),
(59, 0, 'y', 1544386140),
(60, 0, '1', 1544386217),
(61, 0, '1', 1544386243),
(62, 0, '1', 1544386246),
(63, 0, '1', 1544386250),
(64, 0, '1', 1544386263),
(65, 0, '1', 1544386286),
(66, 0, '2', 1544386309),
(67, 0, '?', 1544386354),
(68, 0, '?', 1544386364),
(69, 2, '?', 1544386410),
(70, 0, '?', 1544386421),
(71, 2, '?', 1544386440),
(72, 2, '?', 1544386542),
(73, 1, '?', 1544386550),
(75, 0, 'user', 1544386714),
(76, 3, 'user1', 1544386723),
(77, 4, 'user2', 1544386730),
(78, 1, 'Karol', 1544386739),
(79, 2, 'Krzysiek', 1544386749),
(81, 2, 'DUPA', 1544387669),
(82, 1, 'DUPA2', 1544387688),
(83, 2, 'xd', 1544387692),
(84, 0, 'zxczxc', 1544387720),
(85, 1, 'asdasd', 1544921308);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(0, 'user', 'user'),
(1, 'Karol', 'Karol'),
(2, 'Krzysiek', 'Krzysiek'),
(3, 'user1', 'user1'),
(4, 'user2', 'user2');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`message_id`);

--
-- Indeksy dla tabeli `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `chat`
--
ALTER TABLE `chat`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT dla tabeli `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
